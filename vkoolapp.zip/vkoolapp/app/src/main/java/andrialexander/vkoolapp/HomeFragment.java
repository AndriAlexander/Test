package andrialexander.vkoolapp;


import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewPager;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.TranslateAnimation;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import andrialexander.vkoolapp._sliders.FragmentSlider;
import andrialexander.vkoolapp._sliders.SliderIndicator;
import andrialexander.vkoolapp._sliders.SliderPagerAdapter;
import andrialexander.vkoolapp._sliders.SliderView;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;


/**
 * A simple {@link Fragment} subclass.
 */
public class HomeFragment extends Fragment {

    private SliderPagerAdapter mAdapter;
    private SliderIndicator mIndicator;

    private ViewPager viewPager;
    private LinearLayout sliderDotPanel;
    private int dotscount;
    private ImageView [] dots;
    private ViewPagerAdapter viewPagerAdapter;


    private TextView tv_text, tv_time;
    private SliderView sliderView;
    private LinearLayout mLinearLayout;
    public HomeFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_home, container, false);

        tv_time = rootView.findViewById(R.id.tv_time);
        tv_text = rootView.findViewById(R.id.tv_text);
        sliderView = rootView.findViewById(R.id.sliderView);
        mLinearLayout = rootView.findViewById(R.id.pagesContainer);
        setupSlider();

        viewPager = rootView.findViewById(R.id.view_Page_News);
        viewPagerAdapter = new ViewPagerAdapter(this.getActivity()  );
        viewPager.setAdapter(viewPagerAdapter);

        sliderDotPanel = (LinearLayout) rootView.findViewById(R.id.sliderDot);
        dotscount = viewPagerAdapter.getCount();
        dots = new ImageView[dotscount];

        Display display = getActivity().getWindowManager().getDefaultDisplay();
        float width = display.getWidth();
        final TranslateAnimation animation = new TranslateAnimation(0.0f,  20.0f, 0.0f,0.0f);
        animation.setDuration(5000);
        animation.setRepeatCount(5);
        animation.setRepeatMode(2);
        animation.setFillAfter(true);
        viewPager.setAnimation(animation);
        

        tv_text.setText("PT. Solar Control Specialist adalah perusahaan gabungan atau “Merger” dari 10 dealer V-KOOL yang bergerak dibidang penjualan dan pemasangan kaca film,dan pada awalnya didirikan atau diresmikan pada tanggal 18 Juli 2005 sebagai main dealer untuk penyedia dan pemasangan kaca film V-KOOL.\n" +
                "\n" +
                "Selama lebih dari delapan belas tahun, V-KOOL merupakan kaca film terkemuka yang mampu memberikan solusi atas masalah visibilitas dan tampilan dari kaca film konvensional, disamping itu secara signifikan mengurangi panas matahari.\n" +
                "\n" +
                "Teknologi V-KOOL mengacu pada penolakan panas di jendela ketimbang penyerapan panas seperti keramik maupun teknologi lainnya. Ketika di terapkan pada kaca, VKOOL membiarkan 77% cahaya untuk masuk sementara menolak lebih dari 96% infra-merah dan 99% sinar ultra violet.\n" +
                "\n" +
                "Ganti kaca film jendela yang ada atau pasang pada jendela baru anda. VKOOL adalah pilihan yang tepat untuk kebutuhan Anda dalam menolak panas tanpa mengurangi cahaya yang masuk.");

        Calendar calendar = Calendar.getInstance();
        String currentDate = DateFormat.getDateInstance(DateFormat.FULL).format(calendar.getTime());

        tv_time.setText(currentDate);


        for (int i= 0; i<dotscount; i++){
            dots[i] = new ImageView(this.getActivity());
            dots[i].setImageDrawable(ContextCompat.getDrawable(getActivity().getApplicationContext(),R.drawable.non_active_dot));

            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            params.setMargins(8,0,8,0);

            sliderDotPanel.addView(dots[i], params);
        }

        dots[0].setImageDrawable(ContextCompat.getDrawable(getActivity().getApplicationContext(), R.drawable.active_dot));

        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new myTimeTask(), 2500, 5000);

        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffer, int positionOffSetPixels) {


            }


            @Override
            public void onPageSelected(int position) {
                for (int i=0; i<dotscount; i++){
                    dots[i].setImageDrawable(ContextCompat.getDrawable(getActivity().getApplicationContext(), R.drawable.non_active_dot));
                }
                    dots[position].setImageDrawable(ContextCompat.getDrawable(getActivity().getApplicationContext(), R.drawable.active_dot));
            }

            @Override
            public void onPageScrollStateChanged(int i) {

            }
        });



        return rootView;
    }



    private void setupSlider() {
        sliderView.setDurationScroll(800);
        List<Fragment> fragments = new ArrayList<>();
        fragments.add(FragmentSlider.newInstance("http://solarcontrolspecialist.co.id/assets/images/gambar/slide/mobil1.jpg"));
        fragments.add(FragmentSlider.newInstance("http://solarcontrolspecialist.co.id/assets/images/gambar/slide/viewpic.aspx_1.jpeg"));
        fragments.add(FragmentSlider.newInstance("http://solarcontrolspecialist.co.id/assets/images/gambar/slide/sliderimg23.png"));
        fragments.add(FragmentSlider.newInstance("http://www.vkool-indonesia.com/assets/front/material/banner2.jpg"));

        mAdapter = new SliderPagerAdapter(getFragmentManager(), fragments);
        sliderView.setAdapter(mAdapter);
        mIndicator = new SliderIndicator(getActivity().getApplicationContext(), mLinearLayout, sliderView, R.drawable.indicator_circle);
        mIndicator.setPageCount(fragments.size());
        mIndicator.show();
    }

    public class myTimeTask extends TimerTask{

        @Override
        public void run() {
            HomeFragment.this.getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (viewPager.getCurrentItem()==0){
                        viewPager.setCurrentItem(1) ;
                    }else if (viewPager.getCurrentItem()== 1){
                        viewPager.setCurrentItem(2);
                    }else{
                        viewPager.setCurrentItem(0);
                    }
                }
            });
        }
    }

}



